import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clone-detail',
  templateUrl: './clone-detail.component.html',
  styleUrls: ['./clone-detail.component.scss']
})
export class CloneDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
