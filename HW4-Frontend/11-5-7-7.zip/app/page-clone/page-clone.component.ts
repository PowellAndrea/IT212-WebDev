import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-clone',
  templateUrl: './page-clone.component.html',
  styleUrls: ['./page-clone.component.scss']
})
export class PageCloneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
